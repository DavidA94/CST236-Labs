class Orc(object):
    def __init__(self, distance, velocity = 5):
        self.distance = distance
        self.velocity = velocity
    
