from behave import *
@given("Orc Breached Line")

def step_breached(context):
    ...

@when("shield at 50ft")
    ...
    
@then("shield at 50ft")
    ...
